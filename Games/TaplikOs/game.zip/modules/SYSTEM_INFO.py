class SysInfo:
    osname = "taplik dev"
    version = "2.0.4"
    opisanie = "Dev версия TaplikOs"
    status = "В разработке"


