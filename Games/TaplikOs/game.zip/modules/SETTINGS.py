class SETTINGS:
    enableLogo = False
    enableRootUsers = True
    enableNoRootUsers = True
    enablePythonTerminal = True
    hidePassword = False
    testMessage = "[SETTINGS]: Yes"
